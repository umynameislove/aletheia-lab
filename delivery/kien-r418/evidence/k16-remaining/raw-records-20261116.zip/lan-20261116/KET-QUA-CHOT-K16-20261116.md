# K16 — chốt trên staging LAN chung, 16/11/2026

**K16 đạt 5/5 mục trong phạm vi staging Docker của Kiên được Quân truy cập và thực hành qua Wi-Fi.** Diễn tập cuối có thao tác trực tiếp của Quân và bằng chứng cảnh báo → hành động → hồi phục. K14/K17 giữ các kết quả đo tải của từng bài.

## Trạng thái

| Mục | Kết quả | Chứng cứ |
| --- | --- | --- |
| K16.01 — Observability | PASS, giữ kết quả trước | Telemetry/correlation đã kiểm, bổ sung 126 snapshot collector trong diễn tập. |
| K16.02 — Logging an toàn | PASS, giữ kết quả trước | Contract/redaction giữ nguyên. Bộ thu và bộ nhận giới hạn field, gói bằng chứng không có mã thật/cookie/DSN. |
| K16.03 — Kiểm soát bảo mật | PASS trên staging LAN | TLS, authority, OIDC, tenant, CSRF, asset/path, throttle, secret/collector. |
| K16.04 — Dependency/image | PASS, giữ hồ sơ trước | Kết quả quét giữ đúng digest và thời điểm cũ. Digest image diễn tập được khai báo riêng dưới đây. |
| K16.05 — Alert/runbook | PASS trên staging LAN | Quân nhận cảnh báo và yêu cầu khôi phục từ MacBook; 6 receipt, 8 job khớp hash, 120 readiness đạt. |

SHA nền fa46dd8cbb2239c6f116456894a2009b45846245. Image diễn tập sha256:35ab7a8638b1f3ef7134bfeb87a4bbb6aac0a0101d74857cdaabafee251b8add. Release acbe153cee890b3b5c7c1a8d1a36d100f9ba8cdbce6366005b511a9a7dc5a529. Công cụ điều phối tái lập nằm ở reproduction. Chưa commit/push.

## K16.03 — phương pháp và kết quả

Cụm riêng 713e12808805 có 2 API, 2 worker, PostgreSQL 16, Keycloak 26.8.2 và ingress. Windows 192.168.2.61, MacBook 192.168.2.52 trên Wi-Fi. Origin HTTPS localhost:18776, issuer HTTPS idp-713e12808805.test:18777/realms/k14. Relay giữ nguyên authority; CA thử xác minh TLS. Domain và IdP của staging LAN là môi trường chung dùng trong biên bản này.

| Phép thử | Kết quả |
| --- | --- |
| TLS qua LAN 19176 | TLS 1.3, index/readiness 200; CA không tin cậy và hostname sai đều bị từ chối. |
| Keycloak qua LAN 19177 | Discovery đúng issuer, HTTP 200; OIDC 303 → 200 → 302 → 303 → 200. Cookie Secure, HttpOnly, SameSite=Lax, host-only. |
| Host/session/tenant/CSRF | Host sai 400, ẩn danh 401, chéo workspace 404, cross-site mutation 403. Các lỗi có no-store/nosniff. |
| UI/private path | CSP default-src self, frame-ancestors none, base-uri none; no-referrer, nosniff, no-store. 3 đường private/traversal đều 404. |
| Throttle | 60 lượt/6 luồng, 60 X-Forwarded-For khác nhau: 26 HTTP 303, 34 HTTP 429, Retry-After 9 giây. 12/12 đọc tenant nền đạt, readiness cuối 200. Burst 3,290 giây, auth p95 698,346 ms. |
| Secret | 4/4 API/worker UID 10001, root/mount secret chỉ đọc, drop ALL, no-new-privileges. Secret mode 0400, theo vai trò. |
| Collector | UID 10002; quyền DB đọc cột tối thiểu. Thử sửa job/đọc payload/đọc định danh đều bị 42501. Không mount secret API/worker hoặc Docker socket. |
| Kênh người trực TLS 19016 | Bearer ngẫu nhiên theo lượt, IP MacBook mới được nhận ca/khôi phục. Thiếu mã 403. Máy Kiên có mã cũng bị 403 khi gửi thao tác. |

HSTS vắng mặt trên endpoint localhost của staging. Dữ liệu thử gồm 30 principal, 2 workspace, 6 project/snapshot/result. Bằng chứng ZIP, PDF sandbox và SSRF dùng các kiểm trước theo threat model. Header/issuer của lượt LAN nằm trong k16-dedicated-lan-edge.json; quyền runtime nằm trong runtime-permissions.json.

## K16.05 — thời gian và số đo

Quân nhận ca qua HTTPS, đọc cảnh báo và hàng đợi, rồi gõ KHOIPHUC. Server ghi observer Quan-MacBook, IP 192.168.2.52 và thời điểm tiếp nhận. Bộ điều phối dừng riêng worker K16 sau nhận ca, gửi 72 preview để tạo sự cố, dùng rule collector hiện có.

Các mốc dưới lấy từ server và đổi sang giờ Việt Nam. Đồng hồ MacBook có thể lệch vài giây.

| Sự kiện | ICT |
| --- | --- |
| http_burn API 0 firing | 02:53:11,773804 |
| http_burn API 1 firing | 02:53:11,882500 |
| queue_age firing | 02:53:35,381618 |
| Nhận recover của Quân | 02:53:58,254763 |
| queue_age resolved | 02:54:11,200303 |
| http_burn API 0 resolved | 02:54:27,287641 |
| http_burn API 1 resolved | 02:54:27,374238 |

| Chỉ số | Đạt |
| --- | --- |
| Status | passed_lan_operator_drill |
| Tải | 72 yêu cầu: 8 HTTP 202, 64 HTTP 503 có Retry-After |
| Tenant nền lúc sự cố | 12/12 HTTP 200 đúng scope; p95/max 486,089 ms |
| Health lúc sự cố | 6/6 HTTP 200 |
| Job hồi phục | 8/8 succeeded, attempt 1, SHA-256 nguồn đúng |
| Từ bắt đầu sự cố đến thao tác | 57,766 giây |
| Từ thao tác đến kiểm đủ hồi phục | 28,750 giây |
| Thời gian kiểm đến đủ 8 job | 15,179 giây |
| Health hồi phục | 120/120 HTTP 200 |
| Tenant nền hồi phục | 82,188 ms |
| Collector | 126 snapshot + 1 bản khởi tạo kiểm quyền |
| Giao cảnh báo | 3 firing, 3 resolved; 6/6 receipt khớp thông điệp và HTTP 204 |
| Hàng đợi cuối | 0 job, tuổi 0 |
| Cardinality | Giữ chứng cứ alerts-05: 120 ID khác nhau không tăng số chuỗi metric |

Đã kiểm trực tiếp result.json, traffic/recovery.json, operator-actions/recover.json và toàn bộ thông điệp collector/receiver. Tệp k16-bu-20261116-025253.txt được Quân nêu trong tin nhắn, chưa có bản tệp ở Downloads lúc kiểm. Kết quả trên dựa vào chứng cứ server đối chiếu độc lập.

## Lịch sử và sửa công cụ

Lượt 02:28 hết cửa sổ vì nhập sai. Worker tự chạy lại lúc 02:30:35; 8/8 job được kiểm hash đạt. Lệnh đến muộn vào 02:31 bị cổng cũ báo nhận sau khi diễn tập đóng. Đã sửa cổng để trả 409 khi hết cửa sổ, 410 khi lượt đóng, không ghi thao tác.

Lượt 02:44 dừng do mount đường dẫn Windows có dấu bị đọc sai. Worker tự chạy lại lúc 02:44:48; DB ghi 0 job tạo trong cửa sổ lỗi. Lượt cuối dùng đường dẫn ASCII, kiểm trước 1 job thật trên đúng container/network/OIDC và khớp hash trước khi nhận ca.

Quân báo read -t 5 làm mất chữ đang nhập. reproduction/run-mac-fixed.sh dùng read không timeout, server tiếp tục áp hạn khôi phục và script kiểm lại trạng thái sau khi nhập. Kiểm Bash syntax đạt; kiểm gõ K, dừng 6 giây rồi gõ HOIPHUC và Enter giữ đủ KHOIPHUC đạt. Bản dùng khi diễn tập PASS giữ ở run-mac-used.sh. Hai lần thất bại được giữ nguyên.

Đã dừng cổng nhận ca/khôi phục và xóa tất cả mã diễn tập. Hồ sơ áp dụng staging LAN đã khai báo. Nghiệm thu tổng K01–K18 cho Bảo được lập khi hoàn thành các phần còn lại.
