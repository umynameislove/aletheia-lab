# Bu chạy J01 trên MacBook

Dùng Chrome thử của lượt K14. Staging mở lại, có thể dùng cùng lệnh Chrome trước đó. Nếu Chrome cũ đang báo lỗi mạng thì tải lại.

1. Vào https://localhost:18776/ → Sign in → đăng nhập u0 bằng mật khẩu Kiên đã gửi riêng. Chọn Open workspace nếu chưa có workspace, rồi bấm Connect project.
2. Ở Project ZIP chọn source.zip trong gói J01 này (662 byte), bấm Upload and preview. Đợi phần chọn trường hiện.
3. Mapping:
   - Target source dataset.csv, Target field target, Row identifier id.
   - Metric source metrics.csv, Metric name field name, Metric value field value, Run id run, Step None.
   - Giữ Record classes and units explicitly bật. Class field class, Unit field unit.
   - Metric độ_chính_xác chọn Higher is better, Regression threshold 0.08, unit %.
   - Baseline run lần-0. Giữ đủ 5 run lần-0 tới lần-4. Không chọn config.
4. Chụp ảnh mapping rồi bấm Confirm mapping and save snapshot. Đợi ô câu hỏi.
5. Nhập đúng câu "What is observed in these validated metrics?" rồi Analyze saved snapshot. Đợi màn Investigation và nội dung kết quả dùng được. Dự kiến 10 claim, 10 evidence, 22 node; chỉ mô tả số liệu, causal attribution chưa xác minh.
6. Copy URL lúc này và ghi project/snapshot/result/job từ URL. Chụp ảnh. Reload bằng ⌘+R, kết quả phải đúng cùng câu hỏi và IDs. Để mở 10 giây, báo lỗi nếu có.
7. Chọn 1 claim. Kiểm layout mặc định (panel nguồn); thử thêm layout=reading vào query của hash để xem phương án đọc liên tục. Xác nhận đề xuất A mặc định, B là lựa chọn đọc, hoặc ghi lý do khác.
8. Gửi giờ bắt đầu/kết thúc, thời gian tới result/reload, hai ảnh, URL hoặc IDs và xác nhận 4 dòng cuối NOI-DUNG-CHOT-J01.md. Trace chỉ ghi method/path/status/timing, che cookie/token/CSRF/code/password. Gửi cả lỗi nếu lượt chưa đạt.

Nếu session hết hạn 15 phút, đăng nhập lại rồi chạy lại phần đang kiểm. Không cần import database hay seed toàn catalog cho phép thử slice này.

SHA source.zip bc8328265b884be112c6f782d928969f77368f97f41d0dac53b8fa203dac3981.
Schema version product-api/v1-draft; bản UI và backend xác định bằng release-manifest.json.
