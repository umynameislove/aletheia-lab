# J01 — bản chốt gửi Quân ngày 16/11/2026

Trạng thái là chờ Quân xác nhận bốn dòng cuối sau khi đối chiếu gói. Phía Kiên đã chuẩn bị và kiểm kỹ thuật trên staging LAN. Các quyết định phía UI và việc chạy slice cùng staging cần Quân ghi kết quả thực.

## J01.01 — cùng nền và quyền sở hữu

- Nhánh ghép product-api tại fa46dd8cbb2239c6f116456894a2009b45846245. GitHub xác nhận 11/11 check completed/success trên SHA này. main ở 2bbcdc2 giữ vị trí hiện tại.
- UI-b của Quân có lineage 93e6d635b662224c544fb65279c52be08ac12b21ca01131465fa733e7a6f0f98 đã ghép vào nhánh. Staging có thêm hai sửa cục bộ: lịch kiểm quyền và mở workspace từ deep link cùng tab. Hai sửa đã được Quân kiểm trên MacBook ở FL-134/FL-139.
- Runtime identity acbe153cee890b3b5c7c1a8d1a36d100f9ba8cdbce6366005b511a9a7dc5a529; image sha256:35ab7a8638b1f3ef7134bfeb87a4bbb6aac0a0101d74857cdaabafee251b8add.
- UI build identity e160a882952708ca4e1c8ebbc6439e902a43b40fcd8ba37c50fbd35d575ae3ab, index SHA-256 9bf16d4c6787f44798aa559be9dd885c82e1bcef06071979b1d5f30224d1d910. Manifest ghi hash từng asset, patch hai sửa nằm trong gói.
- Kiên chịu trách nhiệm backend/domain/schema/fixture producer/runtime/migration và staging. Quân chịu trách nhiệm UI/design/reader consumer và browser evidence. Với file/schema dùng chung, Kiên giữ producer và gửi fixture, Quân giữ consumer; hai bên đối chiếu trước khi đổi contract. WIP khác tiếp tục được giữ trong worktree.
- CI 11/11 gắn SHA nền. Hai sửa staging chưa commit/push, được nhận diện bằng patch/manifest riêng.

## J01.02 — contract/fixtures và lựa chọn

- Contract dùng product-api/v1-draft; ProductView reader tiếp tục nhận phiên bản được hỗ trợ v1/v2. Model lớn v3 phải theo capability và bộ schema của nó khi triển khai sau.
- Schema/fixtures trong gói xuất từ đúng source của nền staging, không lấy nguồn WIP K17. 17 fixture đạt JSON Schema độc lập, gồm ca needs_workspace. Có kiểm code/status, date-time, cursor, status_url và extension. Producer contract tests 105/105; consumer hiện tại đọc cùng bộ fixture đạt 18/18.
- OpenAPI được tái xuất từ source ổn định, gồm 102 operation/58 path/103 schema, 1096 local reference và 102 kiểm method/handler đạt. File operation-disposition.json map đủ 38 ID yêu cầu, có mô tả đường thay thế/chức năng theo capability.
- GET session cung cấp context/CSRF; mutation mang X-CSRF-Token, Origin và Idempotency-Key hoặc If-Match theo từng tuyến. 202 xác nhận durable receipt, job terminal và output mới xác nhận kết quả. Consumer luôn đối chiếu workspace/project/snapshot/result, HTTP status và schema_version.
- Giữ no-store cho nội dung private. Tính năng thiếu capability coi là chưa có. Quyền và 404 theo object do server kiểm lại. Mất session và mất quyền workspace được theo dõi bằng lỗi riêng trong hợp đồng; các ca hành vi UI khác thuộc J02.
- Hỏi tối đa 2000 ký tự theo capabilities hiện chạy. Giới hạn được công bố cho bản ghép này, người gọi không suy ra từ text ví dụ cũ.
- Hai phương án layout đã có từ nhánh Quân: A Claim + source panel và B Continuous reading. Quân xác nhận hai phương án còn dùng được trên kết quả thật, và chốt đề xuất A làm mặc định, B là lựa chọn đọc trong URL. Bảo có thể review thiết kế ở vòng bàn giao.
- Với fixture 10 claim hiện tại, lexeme/số và citation hiển thị theo producer; không tự đổi đơn vị hoặc kết luận quan hệ nhân quả ngoài dữ liệu.

## J01.03 — vertical slice thật

Staging gồm Keycloak HTTPS, hai API, hai worker riêng, PostgreSQL TLS và object storage Docker. Quân đã login, chọn workspace và xem kết quả có sẵn qua MacBook. Cần Quân chạy thêm ZIP→preview→confirm→analyze→result→reload trong cùng gói ở HUONG-DAN-BU.md.

Phía Kiên đã chạy bằng Chrome thật:
- OIDC login và vào workspace 1747 ms.
- Upload ZIP và preview 2969 ms.
- Mapping v2 và confirm 2778 ms.
- Analyze đến màn result sử dụng được 3163 ms.
- Reload cùng kết quả 806 ms.
Đây là một mẫu mỗi thao tác. Lần kiểm đầu trong driver chờ chưa đúng mốc DOM/directory nên dừng trước nghiệp vụ. Driver đã sửa để đợi danh sách và màn result sử dụng được, trước khi đo lượt trên.

ZIP source có 662 byte, SHA-256 bc8328265b884be112c6f782d928969f77368f97f41d0dac53b8fa203dac3981. PostgreSQL xác nhận source/snapshot tồn tại, analyze job succeeded, result metadata/object/projection được ghi. Có 10 claim, 10 evidence, 22 node. Reload nhận cùng JSON view SHA-256 cad69d873f87d2116c3a665cc12944d005c99172b10ce595aa6ca18c91359695. IDs gắn trong browser-slice-result.json, DB witness trong postgres-witness.json.

Nếu Quân dùng câu hỏi khác, result_id có thể khác. Đối chiếu lại cùng IDs của chính lượt MacBook sau reload.

## J01.04 — mục tiêu, nguồn lực và quyền thử

Đề xuất chốt hiện tại:
- Chủ staging/DB/IdP/secrets là Kiên trên Docker máy Kiên. Máy thử ngoài host là MacBook Quân M1 8 GB. Tài khoản và vật liệu thử synthetic, cùng LAN. Quyền dùng Docker local không phát sinh mua dịch vụ đã được Kiên xác nhận trong chat; ngân sách dịch vụ/cloud cho gói J01 này là 0 đồng mua mới.
- Cấu hình đang đo: 2 API mỗi replica 0,75 core/512 MiB/pool 4, 2 worker mỗi replica 1 core/640 MiB/pool 2; ingress 0,25 core/96 MiB; PostgreSQL 1 core/640 MiB, max_connections 24; Keycloak 1 core/640 MiB. Tổng pool API+worker 12, reserve quản trị 4 → ngân sách 16; có slot health riêng mỗi API.
- Slice J01 chạy tuần tự, mỗi thời điểm 1 nghiệp vụ, không quá 10 phút mỗi lượt. Dừng và báo khi sai scope/hash, dữ liệu private lộ, job kết thúc sai hoặc timeout liên tiếp; người trực Kiên/Bu có thể yêu cầu dừng. Giữ log kết quả lỗi.
- Mục tiêu vẫn giữ 50.000 unique authenticated principals, 2.000 workspace, 10.000 project, 200.000 snapshot, 2 triệu result. S/M/L yêu cầu 100/1.000/10.000 claim. SLO/deadline/correctness theo đề được kèm nguyên văn ở SLO-VA-TAI-NGUYEN.md. Công việc tạo/nhập catalog và chiến dịch capacity thuộc K17/J06/J07.
- Giữ hai profile tham chiếu của Quân: 1 action/10 s và profile đọc 1 action/20–30 s. Role/journey/think-time là giả định đến khi chốt campaign thực. Từng request/poll/capability/job/byte phải được đưa vào phép tính fanout và ngân sách. Thông số của profile 50k sẽ khóa trước chạy capacity.
- Phản hồi MacBook có 65 request xác nhận quyền trong khoảng 60 giây ở tab kết quả, tương đương 1,083 request/s/tab. Nếu ngoại suy 50k tab như vậy sẽ khoảng 54.167 request/s cho chính chuỗi đọc này. Đây là phép tính từ mẫu, cần sizing và đối chiếu budget trước campaign; không thể lấy giả định 833 session/s cũ làm số đo của UI hiện tại.
- Lượt đối chứng K14 trên cùng host đo 99/99 hành trình trong 92,36 giây, 59 job và 40 export khớp. Pilot chưa cung cấp ngân sách đã chứng minh cho 50k. Nhu cầu mua server/storage chưa có đơn giá hay phê duyệt, sẽ ghi riêng khi có phương án.
- Mục J01 chốt định nghĩa/nguồn lực được phép/cách đo và người phụ trách. Các số đo capacity 50k được nghiệm thu tại campaign tương ứng.

## Mẫu trả lời Quân

Xin trả lời dựa trên đối chiếu và lượt chạy thật, mục thiếu ghi rõ bước/owner.

J01.01 — Đồng ý cùng SHA nền + manifest UI và phân công nêu trên / còn vướng ...
J01.02 — Fixture/schema/contract + question_chars 2000 + layout A mặc định/B lựa chọn đọc — đồng ý / điểm cần sửa ...
J01.03 — Giờ chạy ..., u0, workspace ..., source SHA ..., project/snapshot/result/job của lượt ..., mở/reload đúng ..., ảnh/trace ...
J01.04 — Đồng ý tài nguyên Docker local, MacBook máy thử, 0 dịch vụ mua mới, SLO và mục tiêu 50k như tài liệu, ghi rõ fanout hiện tại và nhiệm vụ campaign / còn vướng ...

Cần kết quả S01–S05 trên cùng staging để cùng ký J01. Những phần J02–J08 khác tiếp tục giữ hồ sơ của chúng.
