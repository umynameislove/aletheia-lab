# K07 — Commit, push và kết quả CI cuối

**Đã commit và push riêng bản sửa race K07 lên `product-api`. CI đạt 11/11 check thành công ngay lượt đầu, không rerun.** Xác minh lúc 2026-11-15T03:21:40.718733+07:00.

Commit `5ac1c54d90ce1ee507e4cdce3b0f8310b49505cf` — `fix(uploads): reconcile concurrent completion under the assembly lock`. Parent `731f1bc2225805262761a21483cec3c693e6b9d4`. Commit gồm 11 tệp chỉ thuộc bản sửa K07, test mới và bằng chứng; 1.389 dòng thêm/6 dòng bỏ tính cả hồ sơ, nằm trong giới hạn 3.000 dòng mỗi commit. Production chỉ đổi một tệp với 8 dòng thêm/6 dòng bỏ. Hồ sơ K09.03 đang ở máy không được đưa vào commit. Đã push bằng refspec `HEAD:refs/heads/product-api`; không push hay merge main.

GitHub kiểm merge tạm PR `39ae4d2ee735cac7b6d6b9f7d5d3e35e53273632`. Cây mã merge và cây mã head cùng `4c15417183eae18490c4b6f9997e51375e4180d8`, đã đối chiếu qua API GitHub. Merge tạm của PR là ref kiểm thử, không phải thao tác ghép vào nhánh main. Hai hash source/test trong `github-ci-result.json` trùng mã đã kiểm 49 ca Windows và 18 ca Linux tại máy.

## CI và thời gian từng job

| Workflow / job | Bắt đầu UTC | Kết thúc UTC | Thời gian job | Kết quả |
| --- | --- | --- | ---: | --- |
| ci / test (3.12) | 2026-11-14T18:55:33Z | 2026-11-14T19:42:27Z | 2814 giây | success, lượt 1 |
| ci / test (3.11) | 2026-11-14T18:55:33Z | 2026-11-14T20:17:17Z | 4904 giây | success, lượt 1 |
| ci / windows-project (0) | 2026-11-14T18:55:33Z | 2026-11-14T19:13:28Z | 1075 giây | success, lượt 1 |
| ci / quality | 2026-11-14T18:55:33Z | 2026-11-14T18:57:06Z | 93 giây | success, lượt 1 |
| ci / security | 2026-11-14T18:55:33Z | 2026-11-14T18:56:28Z | 55 giây | success, lượt 1 |
| ci / application | 2026-11-14T18:55:33Z | 2026-11-14T18:57:06Z | 93 giây | success, lượt 1 |
| ci / windows-project (1) | 2026-11-14T18:55:33Z | 2026-11-14T19:17:58Z | 1345 giây | success, lượt 1 |
| hosted backend / dashboard | 2026-11-14T18:55:33Z | 2026-11-14T18:57:44Z | 131 giây | success, lượt 1 |
| hosted backend / backend | 2026-11-14T18:57:46Z | 2026-11-14T19:13:19Z | 933 giây | success, lượt 1 |
| dependency-audit / audit (3.11) | 2026-11-14T18:55:33Z | 2026-11-14T18:56:18Z | 45 giây | success, lượt 1 |
| dependency-audit / audit (3.12) | 2026-11-14T18:55:33Z | 2026-11-14T18:56:14Z | 41 giây | success, lượt 1 |

Thời gian job tính từ startedAt đến completedAt, gồm cài đặt và dọn môi trường. `jobs.csv` chứa từng job ID, timestamp và URL. Không có job fail, cancelled hoặc phải chạy lại ở SHA này.

## Kết quả các bộ kiểm thử

| Bộ kiểm | Pass | Skip / deselect | Thời gian pytest / test |
| --- | ---: | --- | ---: |
| Python 3.11 full | 11.462 | 56 skip, 7 warning | 2.969,52 giây |
| Python 3.12 full | 11.462 | 56 skip, 7 warning | 1.900,30 giây |
| Evaluation Python 3.11, ba lượt | 4.041 mỗi lượt | 9 skip mỗi lượt | 628,18 / 576,16 / 624,96 giây |
| Evaluation Python 3.12 | 4.041 | 9 skip | 794,49 giây |
| Architecture/maintainability | 126 mỗi interpreter | 0 | 14,55 / 19,58 giây |
| Native hosted PostgreSQL | 440 | 11 skip | Theo step/job metadata |
| Query-probe PostgreSQL | 4 | 0 | Theo step/job metadata |
| Offline hosted | 2.985 | 13 skip, 5 deselect | 56,76 giây |
| Consumer UI | 359 | 0 | 10.836,648664 ms |
| Application | 162 | 0 | 33,94 giây |

Full Python 3.11 coverage **88,72%**, qua ngưỡng 88%; 95.615 statement, 10.781 miss theo log. Application coverage **92,31%**. Mypy strict của cả Python 3.11 và 3.12 đạt trên 403 tệp source. Lint, mutation audit, maintainability, repo hygiene, Bandit và cả hai audit dependency đều success. Hai dependency audit ghi không có lỗ hổng đã biết trong phạm vi môi trường được quét.

Windows shard 0 đạt project 730 pass/39 skip/10.749 deselect; product 268 pass; evaluation 1.788 pass/5 skip; publication 284 pass. Shard 1 đạt project 730 pass/39 skip/10.749 deselect; product 268 pass; evaluation 2.248 pass/9 skip; publication 284 pass. Thời gian và từng dòng tổng kết được lưu trong `github-ci-result.json` và `test-summary-lines.json`.

Các bộ trên có ca trùng nhau, không cộng thành số ca duy nhất. Skip/deselect giữ nguyên nghĩa chưa thực thi ở profile đó, không tính thành pass. Native dùng -qq nên không in dòng tổng kết: số 440/11 và query-probe 4 được đếm từ dấu tiến độ . / s của đúng step; raw log giữ nguyên để kiểm lại.

## Kiểm chứng bản sửa race

Trước sửa, bài ép thứ tự trên PostgreSQL thật cho 3/8 caller đã tái hiện 2 fail ở ready và 8 pass ở các ca bảo vệ. Sau sửa tại máy, 10/10 ca ép race pass; hồi quy Windows tổng 49/49 và Linux/Python 3.12 tổng 18/18, không skip. Mỗi ZIP 412 byte, 4 part; có đúng một source và một source.put audit khi winner hoàn tất, caller chờ nhận cùng receipt, không parse lại. Hủy, hết hạn, mất membership hoặc session vẫn bị chặn; byte reservation về 0. Các số đo từng ca và log trước/sau nằm ở `../race-cases.csv`, `../raw-test-logs.zip`, `../KET-QUA-RACE-K07.md`.

Trong CI, module 10 ca mới được chọn qua glob native `tests/integration/test_k0[2-9]_*.py` với K07_TEST_DATABASE_URL có giá trị trên DB dịch vụ riêng; điều kiện skip do thiếu URL không kích hoạt. Bộ native tăng từ 430 pass của SHA trước lên 440 pass ở SHA sửa, cùng 11 skip. Full matrix tăng từ 11.452 lên 11.462 pass mỗi interpreter, cùng 56 skip. Cả bài từng fail `test_real_resume_out_of_order_parallel_retry_lost_ack_and_complete_once` và module ép race mới đều nằm trong bộ chạy.

Linux CI dùng PostgreSQL 16.16, image postgres:16-bookworm pin theo workflow; Python 3.11.18 và 3.12.16. Phiên bản runner đọc trực tiếp từ log nằm trong `github-ci-result.json`. URL PostgreSQL dùng dữ liệu tổng hợp ở loopback 5432, thông tin credential bị GitHub che trong log. Không đổi workflow, timeout hay ngưỡng pass để đạt kết quả này.

## Hồ sơ và phạm vi chốt

Đã lưu nguyên ba ZIP log GitHub, metadata ba workflow, snapshot 11 check của PR #193, hai commit/tree từ API, bảng thời gian từng job và từng dòng tổng kết. `manifest.json` kiểm toàn vẹn hồ sơ CI. `published-file-hashes.json` ghi hash byte thực đã lưu trong Git; hồ sơ gốc tạo trên Windows có chuẩn hóa CRLF sang LF khi đưa vào Git nên hai dạng được ghi rõ. Mã source/test khớp chính xác ở cả hai dạng.

Các cờ chưa commit/chưa push trong hồ sơ gốc là ảnh chụp trước phát hành, theo timestamp của lần đo tại máy. Trạng thái hiện tại là đã commit/push SHA nêu trên và CI 11/11 pass. Báo cáo CI bổ sung này được lưu tại máy sau khi CI xong; không tạo commit mới chỉ để ghi kết quả rồi làm thay đổi SHA đang được xác minh.

Chốt lỗi race hoàn tất upload K07 và hồi quy liên quan. Chưa triển khai staging hoặc đo sức chịu tải thực tế; 3/8 caller là kiểm tính đúng tranh chấp, không phải công bố RPS hay mức tải triển khai. Không sửa phần khác và không xuất nghiệm thu toàn bộ K01–K18 cho Bảo ở lần này.

[Commit đã push](https://github.com/umynameislove/aletheia-lab/commit/5ac1c54d90ce1ee507e4cdce3b0f8310b49505cf), [CI](https://github.com/umynameislove/aletheia-lab/actions/runs/43629272945), [hosted backend](https://github.com/umynameislove/aletheia-lab/actions/runs/43629272843), [dependency-audit](https://github.com/umynameislove/aletheia-lab/actions/runs/43629272856).
